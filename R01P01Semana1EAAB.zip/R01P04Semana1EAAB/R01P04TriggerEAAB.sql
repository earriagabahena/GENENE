---CREACION De TRIGGER DE PRUEBA


CREATE OR ALTER TRIGGER trg_AddRuta_UpDateChofer
ON dbo.Rutas
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE c
    SET Disponibilidad = 0
    FROM dbo.Choferes c
    INNER JOIN inserted i 
        ON c.IdChofer = i.IdChofer;
END;




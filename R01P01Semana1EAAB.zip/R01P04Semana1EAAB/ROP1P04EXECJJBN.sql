USE GenE
EXEC Listar_Camiones;
EXEC Listar_Camiones @Disponibilidad = 1;
EXEC Listar_Camiones @Disponibilidad = 0;

EXEC Insert_Camiones
    @Matricula = 'ABC-123',
    @TipoCamion = 'Carga',
    @Modelo = 2023,
    @Marca = 'Kenworth',
    @Capacidad = 20,
    @Kilometraje = 150000,
    @UrlFoto = 'camion1.jpg';

	EXEC Obtener_Camion_PorID @IDCamion = 1;

	EXEC Update_Camion
    @IDCamion = 1,
    @Matricula = 'XYZ-999',
    @TipoCamion = 'Refrigerado',
    @Modelo = 2024,
    @Marca = 'Freightliner',
    @Capacidad = 25,
    @Kilometraje = 90000,
    @Disponibilidad = 1,
    @UrlFoto = 'camion_update.jpg';

	EXEC Delete_Camion @IDCamion = 1; 


	EXEC Insertar_Chofer
    @Nmbre = 'Juan',
    @ApPaterno = 'Perez',
    @ApMaterno = 'Lopez',
    @Telefono = '4921234567',
    @FechaNacimiento = '1990-05-10',
    @Licencia = 'LIC-12345',
    @UrlFoto = 'chofer1.jpg';

	EXEC Listar_Choferes;

	EXEC Listar_Choferes @Disponibilidad = 1;

	EXEC Listar_Choferes @Disponibilidad = 0;

	EXEC Update_Chofer
    @IDChofer = 1,
    @Nombre = 'Carlos',
    @ApPaterno = 'Ramirez',
    @ApMaterno = 'Gomez',
    @Telefono = '4929998888',
    @FechaNacimiento = '1988-09-15',
    @Licencia = 'LIC-99999',
    @UrlFoto = 'chofer_update.jpg',
    @Disponibilidad = 1;

	EXEC Delete_Chofer @IDChofer = 1;
	EXEC Existe_Licencia @Licencia = 'LIC-12345';
	EXEC Existe_Matricula @Matricula = 'ABC-123';
	
	EXEC Insertar_Ruta
    @IDChofer = 1,
    @IDCamion = 2,
    @Origen = 'Zacatecas',
    @Destino = 'Guadalajara',
    @FechaSalida = '2026-01-12 08:00',
    @FechaLlegada = '2026-01-12 16:00',
    @ATiempo = 1,
    @Distancia = 520.5; ---Error

EXEC Listar_Rutas;--Error


	EXEC Update_Ruta
    @IDRuta = 1,
    @IDChofer = 1,
    @IDCamion = 2,
    @Origen = 'Zacatecas',
    @Destino = 'CDMX',
    @FechaSalida = '2026-01-13 07:00',
    @FechaEntrada = '2026-01-13 15:30',
    @ATiempo = 1,
    @Distancia = 650.0;--Error

	EXEC Delete_Ruta @IDRuta = 1;--error

	USE GenE;
GO
-----------------------------------------------

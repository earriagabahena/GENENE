﻿/*=====================================================
  BASE DE DATOS: GenE
  Author: Jose Juan Basurto Najera
  Fecha: 11/01/2026
  Descripción: Creación completa de la BD y tablas
=====================================================*/

------------------------------------------------------
--  CREAR BASE DE DATOS (SEGURO)
------------------------------------------------------
USE GenE;
GO

IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'GenE')
BEGIN
    CREATE DATABASE GenE;
END
GO


------------------------------------------------------
-- 2 USAR BASE DE DATOS
------------------------------------------------------
USE GenE;
GO


------------------------------------------------------
 --TABLA CAMIONES
------------------------------------------------------
IF OBJECT_ID('dbo.Camiones', 'U') IS NOT NULL
    DROP TABLE dbo.Camiones;
GO

CREATE TABLE Camiones (
    IDCamion INT IDENTITY(1,1) PRIMARY KEY,
    Matricula NVARCHAR(100),
    TipoCamion NVARCHAR(50),
    Modelo INT,
    Marca NVARCHAR(50),
    Capacidad INT,
    Kilometraje DECIMAL(10,2),
    Disponibilidad BIT,
    UrlFoto NVARCHAR(100),
    FechaRegistro DATETIME DEFAULT GETDATE()
);
GO


------------------------------------------------------
-- 4️ TABLA CHOFERES
------------------------------------------------------
IF OBJECT_ID('dbo.Choferes', 'U') IS NOT NULL
    DROP TABLE dbo.Choferes;
GO

CREATE TABLE Choferes (
    IDChoferes INT IDENTITY(1,1) PRIMARY KEY,
    Nombre NVARCHAR(100),
    ApPaterno NVARCHAR(100),
    ApMaterno NVARCHAR(100),
    Telefono NVARCHAR(50),
    FechaNacimiento DATE,
    Licencia NVARCHAR(50),
    UrlFoto NVARCHAR(50),
    Disponibilidad BIT,
    FechaRegistro DATETIME DEFAULT GETDATE()
);
GO


------------------------------------------------------
-- 5️⃣ TABLA RUTA
------------------------------------------------------
IF OBJECT_ID('dbo.Ruta', 'U') IS NOT NULL
    DROP TABLE dbo.Ruta;
GO

CREATE TABLE Ruta (
    IDRuta INT IDENTITY(1,1) PRIMARY KEY,
    IDChoferes INT NOT NULL,
    IDCamion INT NOT NULL,
    Origen NVARCHAR(50),
    Destino NVARCHAR(50),
    FechaSalida DATETIME,
    FechaLlegada DATETIME,
    ATiempo BIT,
    Distancia FLOAT,
    FechaRegistro DATETIME DEFAULT GETDATE(),

    CONSTRAINT FK_Ruta_Choferes
        FOREIGN KEY (IDChoferes) REFERENCES Choferes(IDChoferes),

    CONSTRAINT FK_Ruta_Camion
        FOREIGN KEY (IDCamion) REFERENCES Camiones(IDCamion)
);
GO


------------------------------------------------------
-- 6️⃣ TABLA AUDITORÍA DE CHOFERES
------------------------------------------------------
IF OBJECT_ID('dbo.AuditoriaChoferes', 'U') IS NOT NULL
    DROP TABLE dbo.AuditoriaChoferes;
GO

CREATE TABLE AuditoriaChoferes (
    IDAuditoria INT IDENTITY(1,1) PRIMARY KEY,
    IDChoferes INT NOT NULL,
    Accion NVARCHAR(50),
    Fecha DATETIME DEFAULT GETDATE(),

    CONSTRAINT FK_Auditoria_Choferes
        FOREIGN KEY (IDChoferes) REFERENCES Choferes(IDChoferes)
);
GO


------------------------------------------------------
--  VALIDACIÓN FINAL
------------------------------------------------------
SELECT name AS Tablas_Creadas
FROM sys.tables;
GO





-- Si la tabla existe, se elimina (opcional para pruebas)
IF OBJECT_ID('dbo.Ruta', 'U') IS NOT NULL
    DROP TABLE dbo.Ruta;
GO

CREATE TABLE Ruta (
    IDRuta INT IDENTITY(1,1) PRIMARY KEY,
    IDChoferes INT NOT NULL,
    IDCamion INT NOT NULL,
    Origen NVARCHAR(50) NOT NULL,
    Destino NVARCHAR(50) NOT NULL,
    FechaSalida DATETIME NOT NULL,
    FechaLlegada DATETIME NOT NULL,
    ATiempo BIT NOT NULL,
    Distancia FLOAT NOT NULL,
    FechaRegistro DATETIME DEFAULT GETDATE(),

    CONSTRAINT FK_Ruta_Choferes
        FOREIGN KEY (IDChoferes)
        REFERENCES Choferes(IDChoferes),

    CONSTRAINT FK_Ruta_Camiones
        FOREIGN KEY (IDCamion)
        REFERENCES Camiones(IDCamion)
);
GO


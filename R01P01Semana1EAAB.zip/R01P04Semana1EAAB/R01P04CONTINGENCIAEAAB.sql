TRUNCATE TABLE Rutas;
GO
DROP TABLE Rutas; 
GO

TRUNCATE TABLE Camiones;
GO
DROP TABLE Camiones;
GO

TRUNCATE TABLE Rutas;
GO

DELETE FROM Rutas
WHERE IdRuta<=5;

GO


DELETE FROM Camiones
WHERE IdCamion<=5;

GO

DELETE FROM Choferes
WHERE IdChofer<=5;

GO


--					CONTINGENCIA				DELETE

--Rutas
DELETE FROM Rutas
WHERE IdRuta=SCOPE_IDENTITY();

GO
--Camiones
DELETE FROM Camiones
WHERE IdCamion<=SCOPE_IDENTITY();

GO
--Choferes
DELETE FROM Choferes
WHERE IdChofer<=SCOPE_IDENTITY();

GO


--					CONTINGENCIA INSERT

IF(OBJECT_ID('dbo.Insert_Camion','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Insert_Camion]

GO


IF(OBJECT_ID('dbo.Insert_Chofer','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Insert_Chofer]

GO


IF(OBJECT_ID('dbo.Insert_Ruta','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Insert_Ruta]

GO

--					CONTINGENCIA			LISTAR

IF(OBJECT_ID('dbo.Listar_Camiones','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Listar_Camiones]

GO




IF(OBJECT_ID('dbo.Listar_Choferes','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Listar_Choferes]

GO



IF(OBJECT_ID('dbo.ListarRutas','P')IS NOT NULL)

DROP PROCEDURE [dbo].[ListarRutas]

GO


--			CONTINGENCIA UPDATE

IF(OBJECT_ID('dbo.Update_Chofer','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Update_Chofer]

GO



IF(OBJECT_ID('dbo.Update_Camion','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Update_Camion]

GO


IF(OBJECT_ID('dbo.Update_Ruta','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Update_Ruta]

GO


--				CONTINGENCIA  DELETE

IF(OBJECT_ID('dbo.Delete_Camion','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Delete_Camion]

GO



IF(OBJECT_ID('dbo.Delete_Chofer','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Delete_Chofer]

GO



IF(OBJECT_ID('dbo.Delete_Ruta','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Delete_Ruta]

GO


IF(OBJECT_ID('dbo.Existe_Licencia','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Existe_Licencia]

GO

--					CONTINGENCIA EXISTE MATRICULA

IF(OBJECT_ID('dbo.Existe_Matricula','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Existe_Matricula]

GO


--					CONTINGENCIA  OBTENER POR ID

IF(OBJECT_ID('dbo.Obtener_Camion_porID','P')IS NOT NULL)

DROP PROCEDURE [dbo].[Obtener_Camion_porID]

GO
CREATE DATABASE GenE

USE GenE


CREATE TABLE Camiones (
	IdCamion INT PRIMARY KEY IDENTITY(1,1),
	Matricula NVARCHAR(100),
	TipoCamion NVARCHAR(100),
	Modelo INT,
	Marca NVARCHAR(100),
	Capacidad INT,
	Kilometraje fLOAT(10),
	Disponibilidad BIT,
	UrlFoto NVARCHAR(100),
	FechaRegistro DATETIME
)


CREATE TABLE Choferes(
	IdChofer INT PRIMARY KEY IDENTITY(1,1),
	Nombre NVARCHAR(100),
	ApPaterno NVARCHAR(100),
	ApMaterno NVARCHAR(100),
	Telefono NVARCHAR(15),
	FechaNacimiento DATE,
	Licencia NVARCHAR(50),
	UrlFoto NVARCHAR(255),
	Disponibilidad BIT,
	FechaRegistro DATETIME DEFAULT GETDATE()
)

CREATE TABLE Rutas(
	IdRuta INT PRIMARY KEY IDENTITY(1,1),
	Origen NVARCHAR(200),
	Destino NVARCHAR(200),
	FechaSalida DATETIME,
	FechaLlegada DATETIME,
	ATiempo BIT,
	Distancia FLOAT(8),
	FechaRegistro DATETIME DEFAULT GETDATE(),
	IdChofer INT FOREIGN KEY REFERENCES Choferes(IdChofer),
	IdCamion INT FOREIGN KEY REFERENCES Camiones(IdCamion)
)

CREATE TABLE AuditoriaChoferes(
	IdAuditoria INT PRIMARY KEY IDENTITY(1,1),
	IdChofer INT FOREIGN KEY REFERENCES Choferes(IdChofer),
	Accion NVARCHAR(50),
	Fecha DATETIME DEFAULT GETDATE()
)




INSERT INTO Camiones(Matricula, TipoCamion, Modelo, Marca, Capacidad, Kilometraje, Disponibilidad)
	VALUES
				('HGDJ34', 'Doble Carga', 2005, 'Nissan', 28, 14889, 0),
				('JDKS38', 'Doble Carga', 1999, 'Volwswagen', 32, 13922, 1),
				('SJAI34', 'Doble Carga', 1995, 'Mercedes', 28, 18292, 0),
				('KXMS83', 'Una Carga', 2004, 'Volwswagen', 24, 13839, 1),
				('DJWK38', 'Doble Carga', 2017, 'Mercedes', 28, 19202, 0)


INSERT INTO Choferes(Nombre, ApPaterno, ApMaterno, Telefono, FechaNacimiento, Licencia, Disponibilidad)
	VALUES
				('Edgar', 'Arriaga', 'Bahena', '555355445', '2002-05-12','JSJSK344', 0),
				('Luis', 'Fernandez', 'De Gante', '554556334', '1994-07-23','JSKSSN33', 1),
				('Juan', 'Hernandez', 'Chavez', '55332442', '2000-05-14', '3833JDJD', 0),
				('Jose', 'Macias', 'Ramirez', '5523462234', '2001-02-22', 'KDKSWIEU8', 1),
				('Jenni', 'Montes', 'Roman', '553313478', '2002-12-28', 'DJSKSHSU83', 0)


INSERT INTO Rutas(Origen, Destino, FechaSalida, FechaLlegada, ATiempo, Distancia)
	VALUES
				('Poza rica', 'Cocula', 21-12-2025, 28-12-2025, 0, 14.000),
				('Iguala', 'Ixcateopan', 18-11-2025, 19-11-25 , 0, 1.330),
				('Taxo', 'Huitzuco', 02-04-2025, 04-04-2025, 1,  0),
				('Morelos', 'Huahuaxtla', 17-08-2025, 15-12-25, 0, 12.000),
				('Xochitepec', 'Cdmx', 12-09-2025, 23-12-2025, 0, 10.200)

INSERT INTO AuditoriaChoferes(Accion)
VALUES	
			('Reunion de choferes'),
			('Reunion de Rutas'),
			('Reunion de camiones')


--CREATE TRIGGER trg_InsertChofer
--ON Choferes
--AFTER INSERT
--AS
--BEGIN
--    INSERT INTO AuditoriaChoferes (IdChofer, Accion)
--    SELECT IdChofer, 'Alta de chofer'
--    FROM INSERTED;
--END;


--CREATE TRIGGER trg_UpdateRuta
--ON Rutas
--AFTER UPDATE
--AS
--BEGIN
--    -- Chofer no disponible
--    UPDATE C
--    SET C.Disponibilidad = 0
--    FROM Choferes C
--    INNER JOIN INSERTED I ON C.IdChofer = I.IdChofer;

--    -- Cami�n no disponible
--    UPDATE CA
--    SET CA.Disponibilidad = 0
--    FROM Camiones CA
--    INNER JOIN INSERTED I ON CA.IdCamion = I.IdCamion;
--END;





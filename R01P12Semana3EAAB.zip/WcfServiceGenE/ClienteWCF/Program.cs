﻿using ClienteWCF.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClienteWCF
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Service1Client cliente  = new Service1Client();

            try
            {
                string mensaje = cliente.HolaMundo();
                Console.WriteLine(mensaje);
                Console.WriteLine();


                string[] usuarios = cliente.ObtenerUsuarios();
                Console.WriteLine("Lista de usuarios:");
                foreach (string usuario in usuarios)
                {
                    Console.WriteLine("-  " + usuario);
                }

                cliente.Close();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Ocurrió un error: " + ex.Message);
            }
            Console.ReadKey();
        }
    }
}

﻿// See https://aka.ms/new-console-template for more information
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Specialized;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Data;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Net.Http.Headers;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.Marshalling;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Encodings.Web;
using System.Transactions;

Console.WriteLine("Hello, World!");

/*Numeros Enteros   */
// int edad = 25;
// int[]  numeros = {1, 2, 3, 4, 5};
// Console.WriteLine(numeros[0]);
// string[] Animales = {"Perro", "gato"};
// Console.WriteLine(Animales[1]);
// // long poblacio = 736336727373737L;

// //Numeros decimales

// decimal precio = 99.99m;
// double pi = 3.1416;
// float temperatura = 35.5F;

// //Texto

// string Nombre = "Edgar";
// char inicial = 'J';

// //Booleano
// bool esACTIVO = True;

// //Fecha y Hora
// DateTime fechaNacimiento = new DateTime(1995, 5, 15);

//Tipo Nullable
// int? edad = null;


// Console.WriteLine(edad);
// Console.WriteLine(Nombre);

// dynamic [] datosmixtos = {"Perro", "7",
// new string[] {"Lista dentro de otra lista", "4"}
// };
// Console.WriteLine(datosmixtos[2] [0]);


// Dictionary<int, string> players = new Dictionary<int, string>
// {
//     {10, "Messi"},
//     {7, "Ronaldo"}
// };

// Console.WriteLine(players[10] + " " + players [7]);



// Dictionary<string, string> Gym = new Dictionary<string, string>
// {
//     {"1", "Edgar"},
//     {"2", "Alex"},
//     {"3", "Jenni"}
// };

// Console.WriteLine(Gym["3"] + " " + Gym["2"] + " " + Gym["1"]);


Dictionary<String, List<String>> Email = 
new Dictionary<String, List<String>>(){
    
    {"Juan", new List<string> {"Juan@gmail.com"}},
    {"Alex", new List<string> {"Alex@gmail.com", "Edgar@gmail"}}
};

Console.WriteLine(Email["Juan"] [0]);



//Reto: Crea un objeto en C# que represente una computadora, con sus respectivas características (marca, modelo, procesador, memoria RAM, etc).



// Dictionary<string, string> Computadora = new Dictionary<string, string>
// {
//     {"Marca", "Lenovo"},
//     {"modelo", "2016"},
//     {"Procesador", "Intel"},
//     {"RAM", "64"}
// };

// Console.WriteLine(Computadora["Marca"] + "\n" + Computadora["modelo"] + "\n" + Computadora["Procesador"] +" \n "+ Computadora["RAM"]);





//                              CONDICIONALES                                                   //

// Bool Autorizado = true;

// 
//     if (Autorizado == true)
//     {
//         Console.WriteLine("Puede ingresar");
//     }else
//     {
//         Console.WriteLine("No puede ingresar");
//     }



// Console.Write("Ingresa un valor");
// int numero = Console.Read();

// if(numero%2 == 0)
// {
//     Console.WriteLine("El numero es par");
// }else
// {
//      Console.WriteLine("No es par");
// }

// Console.Write("Ingresa valor");
// int entero = int.Parse(Console.ReadLine());
// if(entero == 99)
// {
//     Console.WriteLine("En 99");
// }else if(entero == 100)
// {
//     Console.WriteLine("Es 100");
// }
// else
// {
//     Console.WriteLine("No es 99, ni 100");
// };


//                                          BUCLES                                      ///
// Console.WriteLine("Ingresa un color del semaforo \n Verde \n Amarillo \n Rojo");
// string color = Console.ReadLine();

// switch (color)
// {
//     case "Verde":
//         Console.WriteLine("Exito");
//         break;

//     case "Amarillo":
//         Console.WriteLine("Advertencia");
//         break;

//     case "Rojo":
//         Console.WriteLine("Error");
//         break;

//     default:
//         Console.WriteLine("Color no válido");
//         break;
// }


// Console.WriteLine("Ingresa un color del semaforo \n Verde \n Ama");
// string color = Console.ReadLine();

// switch (color)
// {
//     case "Verde":
//         Console.WriteLine("Exito");
//         break;

//     case "Amarillo":
//         Console.WriteLine("Advertencia");
//         break;

//     case "Rojo":
//         Console.WriteLine("Error");
//         break;

//     default:
//         Console.WriteLine("Color no válido");
//         break;
// }



// Console.WriteLine("Ingresa un valor");
// int Valor = int.Parse(Console.Read());

// if(Valor < 10)
// {
//     Console.Write("El valor es menor a 10");
// }else if(Valor == 10)                                                       //------------------------------------------------------------------------------------------------------------------
// {
//     Console.Write("El valor es igual a 10");
// }else if(Valor > 10)
// {
//     Console.Write("El valor es mayor a 10");  
// }



// String[]Alumnos = {"JJ", "Luis", "Edgar"};
//         foreach (String alumno in Alumnos)
//         {
//             Console.WriteLine(alumno);
//         }

// Int[]Numeros = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
//         foreach (Int numero in Numeros)
//         {
//             Console.WriteLine(alumno);
//         }

// int entero = 1;
// int emergencia = 10;

// while(entero <= emergencia)
// {
//     Console.WriteLine(entero);
//     entero ++;
// }


// void suma (int A, int B)
// {
//     Console.WriteLine(A + B);
// }

    
// suma(2, 6);

// int Multi (int A, int B)
// {
    
//     return A * B;
// }

// int resultado = Multi(2, 6);


// Console.WriteLine(resultado);



// void ImprimirPrimerElem(string[]lista)
// {
//     Console.WriteLine(lista[0]);
// }
// String[]Animales = {"Edgar", "Alexis", "Luis"};
// ImprimirPrimerElem(Animales);

//                                                                              QUICKSORF                                                                               //
// int[] Quicksort(int[]lista)
// {
//     if (lista.Length <= 1)
//     {
//        return lista; 
//     }
//     int pivote = lista[0];
//     List<int> Izquierda = new List<int>();
//     List<int> Derecha = new List<int>();
//     for(int i = 1; i<lista.Length; i++)
//     {
//         if(lista[i] < pivote)
//         {
//             Izquierda.Add(lista[i]);
//         }else
//         {
//             Derecha.Add(lista[i]);   
//         }
//     }
//     return Quicksort (Izquierda.ToArray()).Concat(new int[]{
//         pivote }).Concat(Quicksort(Derecha.ToArray())).ToArray();
    
// } 

// int[] numeros = {2, 3, 25, 26, 94, 20, 23};
// int [] listaOrdenada = Quicksort(numeros);
// Console.WriteLine(string.Join(", ", listaOrdenada));


// Lenguaje html = new Lenguaje("html", 1999);
// html.Descripcion();


// gestores_bd html = new gestores_bd("html", 1999, "microsoft");
// html.Descripcion();


int a =5;
int b = a + 5;
bool test = true;
int c = a + test;
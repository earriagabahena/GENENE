// public class Lenguaje
// {
//     public string? Nombre{get; set;}
//     public int? Anio {get; set;}


//     public Lenguaje(string nombre, int anio){
//         Nombre = nombre;
//         Anio = anio;
//     }




//     public void Descripcion()
//     {
//    Console.WriteLine($"{Nombre} fue creado {Anio}"); 
//     }
// }


public class gestores_bd
{
    public string? Nombre{get; set;}
    public int? Lanzamiento {get; set;}
    public string? Desarrollador {get; set;}


    public gestores_bd(string nombre, int lanzamiento, string desarrollador){
        Nombre = nombre;
        Lanzamiento = lanzamiento;
        Desarrollador = desarrollador;
    }

    public void Descripcion()
    {
   Console.WriteLine($"{Nombre} fue creado {Lanzamiento} por {Desarrollador}"); 
    }
}


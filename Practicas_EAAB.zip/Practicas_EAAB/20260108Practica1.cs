// /*Numeros Enteros   */
// int edad = 25
// long poblacio = 736336727373737L;

// Numeros decimales

// decimal precio = 99.99m;
// double pi = 3.1416;
// float temperatura = 35.5F;



// string Nombre = "Edgar";
// char inicial = 'J';

// //
// bool esACTIVO = True;

// //Fecha y Hora
// DateTime fechaNacimiento = new DateTime(1995, 5, 15);

// //Tipo Nullable
// int? edad = null;
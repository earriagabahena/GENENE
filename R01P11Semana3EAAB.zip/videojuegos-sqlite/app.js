const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database'); // Importamos la conexión SQLite (better-sqlite3)
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(express.static(__dirname));

app.use(bodyParser.json());
app.use(cors());

// Ruta principal
app.get('/', (req, res) => {
  console.log('Acceso a la ruta principal /');
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Listar todos los videojuegos
app.get('/guadalajara', (req, res) => {
  console.log('Acceso a GET/guadalajara');
  try {
    const rows = db.prepare('SELECT * FROM guadalajara').all();
    res.json(rows);
  } catch (err) {
    console.error('Error al obtener jugadores:', err.message);
    res.status(500).json({ error: 'Error al obtener jugadores' });
  }
});

// Obtener un videojuego por id
app.get('/guadalajara/:id', (req, res) => {
  const id = parseInt(req.params.id);
  console.log(`Acceso a GET /guadalajara/${id}`);
  try {
    const row = db.prepare('SELECT * FROM guadalajara WHERE id = ?').get(id);
    if (row) {
      res.json(row);
    } else {
      res.status(404).json({ message: 'Jugadores not found' });
    }
  } catch (err) {
    console.error('Error al obtener jugadores:', err.message);
    res.status(500).json({ error: 'Error al obtener jugador' });
  }
});

// Insertar un nuevo
app.post('/guadalajara', (req, res) => {
  console.log('Acceso a POST /guadalajara');
  console.log('Datos recibidos del cliente:', req.body);

  const { nombre, descripcion, numero, posicion, edad, photo, video} = req.body;

  if (!nombre || !descripcion || !numero || !posicion || !edad || !photo || !video) {
    console.error('Error: Datos incompletos');
    return res.status(400).json({ error: 'Todos los campos son obligatorios' });
  }

  try {
    const stmt = db.prepare(
      'INSERT INTO guadalajara (nombre, descripcion, numero, posicion, edad, photo, video) VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    const info = stmt.run(nombre, descripcion, numero, posicion, edad, photo, video);
    console.log('Jugador insertado correctamente con ID:', info.lastInsertRowid);
    res.status(201).json({ id: info.lastInsertRowid, ...req.body });
  } catch (err) {
    console.error('Error al insertar jugador:', err.message);
    res.status(500).json({ error: 'Error al insertar jugador' });
  }
});

// Actualizar un existente
app.put('/guadalajara/:id', (req, res) => {
  const id = parseInt(req.params.id);
  console.log(`Acceso a PUT/guadalajara/${id}`);
  const { nombre, descripcion, numero, posicion, edad, photo, video } = req.body;

  try {
    const stmt = db.prepare(
      'UPDATE guadalajara SET nombre = ?, descripcion = ?, numero = ?,  posicion = ?, edad = ?, photo = ?, video = ? WHERE id = ?'
    );
    const info = stmt.run(nombre, descripcion, numero, posicion, edad, photo, video, id);

    if (info.changes === 0) {
      res.status(404).json({ message: 'guadalajara not found' });
    } else {
      res.json({ id, nombre, descripcion, numero, posicion, edad, photo, video });
    }
  } catch (err) {
    console.error('Error al actualizar:', err.message);
    res.status(500).json({ error: 'Error al actualizar' });
  }
});

// Eliminar un
app.delete('/guadalajara/:id', (req, res) => {
  const id = parseInt(req.params.id);
  console.log(`Acceso a DELETE /guadalajara/${id}`);

  try {
    const stmt = db.prepare('DELETE FROM guadalajara WHERE id = ?');
    const info = stmt.run(id);

    if (info.changes === 0) {
      res.status(404).json({ message: 'jugador not found' });
    } else {
      res.status(204).send();
    }
  } catch (err) {
    console.error('Error al eliminar jugador:', err.message);
    res.status(500).json({ error: 'Error al eliminar jugador' });
  }
});

// Inicio del servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});

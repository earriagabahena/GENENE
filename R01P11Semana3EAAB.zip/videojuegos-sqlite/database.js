const Database = require('better-sqlite3');

// Abrimos o creamos la base de datos
const db = new Database('guadalajara.db');

// Creamos la tabla si no existe
db.prepare(`
  CREATE TABLE IF NOT EXISTS guadalajara (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT,
    descripcion TEXT,
    numero TEXT,
    posicion TEXT,
    edad TEXT,
    photo TEXT,
    video TEXT
  )
`).run();

console.log('Conectado a la base de datos SQLite con better-sqlite3.');

module.exports = db;

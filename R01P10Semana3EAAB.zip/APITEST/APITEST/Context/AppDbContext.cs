﻿using APITEST.Models;
using Microsoft.EntityFrameworkCore;


namespace APITEST.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext>options) : base(options)
        {

        }

        public DbSet<Gestores_Bd> gestores_bd { get; set; }
    }
}

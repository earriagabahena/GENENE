let libro = 'El programador practico'
console.log(libro);